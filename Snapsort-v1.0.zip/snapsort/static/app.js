"use strict";

/* ============================================================
   Snapsort — app logic
   ============================================================ */
const $app = document.getElementById("app");
const $modalRoot = document.getElementById("modal-root");
const $toasts = document.getElementById("toasts");
const $modelPill = document.getElementById("modelPill");
const $modelPillText = document.getElementById("modelPillText");

const state = {
  config: null,
  scan: null,
  categories: [],
  catsOpen: false,
  job: null,
  results: [],
  overrides: new Map(),
  filter: "All",
  search: "",
  destName: "Sorted",
  gridLimit: 240,
  view: "select",
  sortJob: null,
  sortSummary: null,
};

let pollTimer = null;
let modelTimer = null;
let observer = null;
let menuEl = null;
let searchDebounce = null;

/* ------------------------------------------------------------
   API helpers
   ------------------------------------------------------------ */
const api = {
  async get(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error(await this._err(res));
    return res.json();
  },
  async post(url, body) {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
    });
    if (!res.ok) throw new Error(await this._err(res));
    return res.json();
  },
  async _err(res) {
    try {
      const data = await res.json();
      if (data.detail) return typeof data.detail === "string" ? data.detail : JSON.stringify(data.detail);
    } catch (_) { /* ignore */ }
    return `Request failed (${res.status})`;
  },
};

/* ------------------------------------------------------------
   Utilities
   ------------------------------------------------------------ */
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => (
  { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
));
const fmtInt = (n) => new Intl.NumberFormat("en-US").format(n || 0);

function fmtBytes(bytes) {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  const val = bytes / Math.pow(1024, i);
  return `${val >= 100 || i === 0 ? Math.round(val) : val.toFixed(1)} ${units[i]}`;
}

function fmtDuration(sec) {
  if (!isFinite(sec) || sec <= 0) return "—";
  if (sec < 60) return `${Math.ceil(sec)}s`;
  if (sec < 3600) return `${Math.ceil(sec / 60)}m`;
  return `${(sec / 3600).toFixed(1)}h`;
}


/* ------------------------------------------------------------
   Inline SVG icons (emoji fallbacks can render as boxes)
   ------------------------------------------------------------ */
const ICONS = {
  spark: `<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15z"/>`,
  eye: `<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>`,
  bolt: `<path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/>`,
  shield: `<path d="M12 22s8-3.6 8-10V5l-8-3-8 3v7c0 6.4 8 10 8 10z"/><path d="M9 12l2 2 4-4"/>`,
  folder: `<path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V7z"/>`,
  film: `<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 5v14M17 5v14M3 10h4M3 14h4M17 10h4M17 14h4"/>`,
};
function icon(name, cls = "") {
  return `<svg class="ic ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]}</svg>`;
}

function toast(msg, type = "info") {
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  el.textContent = msg;
  $toasts.appendChild(el);
  setTimeout(() => {
    el.classList.add("out");
    setTimeout(() => el.remove(), 300);
  }, 4200);
}

function counts() {
  const c = {};
  for (const r of state.results) {
    const cat = state.overrides.get(r.id) || r.cat;
    c[cat] = (c[cat] || 0) + 1;
  }
  return c;
}

function filteredResults() {
  const q = state.search.trim().toLowerCase();
  return state.results.filter((r) => {
    const cat = state.overrides.get(r.id) || r.cat;
    if (state.filter !== "All" && cat !== state.filter) return false;
    if (q && !r.name.toLowerCase().includes(q) && !r.relpath.toLowerCase().includes(q)) return false;
    return true;
  });
}

/* ------------------------------------------------------------
   Boot
   ------------------------------------------------------------ */
init();

async function init() {
  try {
    state.config = await api.get("/api/config");
    state.categories = state.config.categories.map((c) => ({ ...c }));
    state.destName = state.config.dest_name || "Sorted";
    state.view = "select";
    render();
    updateModelPill(state.config.model);
    modelTimer = setInterval(pollModel, 2000);
  } catch (err) {
    $app.innerHTML = `<section class="card center"><h3>Couldn't start Snapsort</h3><p class="muted">${esc(err.message)}</p></section>`;
  }
}

async function pollModel() {
  try {
    const status = await api.get("/api/model-status");
    updateModelPill(status);
  } catch (_) { /* server may still be booting */ }
}

function updateModelPill(status) {
  if (!status) return;
  $modelPill.className = "model-pill" + (status.state === "ready" ? " ready" : status.state === "error" ? " error" : "");
  $modelPillText.textContent =
    status.state === "ready" ? "AI ready" :
    status.state === "error" ? "AI error" :
    status.state === "downloading" ? `AI model ${Math.round(status.progress * 100)}%` :
    "Loading AI…";
  const note = document.getElementById("modelNote");
  if (note) {
    if (status.state === "ready") note.textContent = "";
    else if (status.state === "downloading") note.textContent = `Downloading AI model… ${Math.round(status.progress * 100)}%`;
    else if (status.state === "loading") note.textContent = "Loading AI model…";
    else if (status.state === "error") note.textContent = "AI model failed to load";
  }
}

/* ------------------------------------------------------------
   Render dispatcher
   ------------------------------------------------------------ */
function render() {
  clearInterval(pollTimer);
  if (observer) { observer.disconnect(); observer = null; }
  closeMenu();

  const views = {
    select: viewSelect,
    scanning: viewScanning,
    ready: viewReady,
    analyzing: viewAnalyzing,
    review: viewReview,
    sorting: viewSorting,
    done: viewDone,
  };
  $app.innerHTML = (views[state.view] || viewSelect)();
  document.body.classList.toggle("has-sortbar", !!document.querySelector(".sortbar"));
  window.scrollTo({ top: 0, behavior: "instant" in document.documentElement.style ? "instant" : "auto" });
  bindView();
}

function bindView() {
  if (state.view === "select") {
    const input = document.getElementById("folderPath");
    if (input) {
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") doScan(); });
      setTimeout(() => input.focus(), 60);
    }
  }
  if (state.view === "ready") {
    const input = document.getElementById("newCat");
    if (input) input.addEventListener("keydown", (e) => { if (e.key === "Enter") addCategory(); });
  }
  if (state.view === "analyzing") startAnalyzePoll();
  if (state.view === "sorting") startSortPoll();
  if (state.view === "review") {
    const search = document.getElementById("search");
    if (search) {
      search.addEventListener("input", () => {
        clearTimeout(searchDebounce);
        searchDebounce = setTimeout(() => {
          state.search = search.value;
          state.gridLimit = 240;
          refreshChips();
          renderGridOnly();
        }, 170);
      });
    }
    const dest = document.getElementById("destName");
    if (dest) {
      dest.addEventListener("input", () => {
        state.destName = dest.value.trim() || "Sorted";
      });
    }
    observeSentinel();
  }
}

/* ------------------------------------------------------------
   Views — select folder
   ------------------------------------------------------------ */
function viewSelect() {
  const demo = state.config && state.config.demo_available;
  return `
  <section class="hero">
    <div class="hero-badge">${icon("spark")} AI-powered photo organizer</div>
    <h2>Thousands of photos.<br/><em>Perfectly sorted</em> in minutes.</h2>
    <p>Point Snapsort at a folder. It looks at every photo and video, understands what's inside, and moves everything into folders like <b>People</b>, <b>Food &amp; Drinks</b>, <b>Travel</b> and <b>Screenshots</b> — automatically.</p>
  </section>

  <section class="card">
    <div class="card-head">
      <h3><span class="step-num">1</span>Choose a folder</h3>
      <span class="sub">JPG · PNG · HEIC · RAW · MP4 · MOV…</span>
    </div>
    <div class="path-row">
      <input id="folderPath" class="input" placeholder="C:\\Users\\you\\Pictures   or   /Users/you/Pictures" value="${esc(state.scan ? state.scan.root : "")}" spellcheck="false"/>
      <button class="btn secondary" data-action="browse">Browse…</button>
      <button class="btn primary" data-action="scan">Scan folder</button>
    </div>
    <div class="row-between">
      <label class="check"><input type="checkbox" id="recursive" checked/> Include subfolders</label>
      ${demo ? `<button class="link" data-action="demo">No photos handy? Try the demo folder →</button>` : `<span class="small muted">Everything stays on this device — nothing is uploaded.</span>`}
    </div>
    <p class="hint">Snapsort never deletes anything: it only <b>moves</b> files into new folders inside the one you pick. You review every category before anything moves.</p>
  </section>

  <div class="features">
    <div class="feature"><div class="fi">${icon("eye")}</div><h4>Understands what's inside</h4><p>An on-device vision model recognizes people, food, travel, screenshots, documents, pets and more — no tags or folders needed.</p></div>
    <div class="feature"><div class="fi">${icon("bolt")}</div><h4>Built for thousands of files</h4><p>Batched analysis and parallel decoding keep things moving, with live progress and an accurate time estimate.</p></div>
    <div class="feature"><div class="fi">${icon("shield")}</div><h4>You stay in control</h4><p>Preview every file, fix any category with one click, then move. A manifest logs every single move.</p></div>
  </div>`;
}

function viewScanning() {
  return `<section class="card center" style="padding:60px 24px">
    <div class="spinner" style="margin:0 auto 18px"></div>
    <h3 style="margin:0 0 6px">Scanning your folder…</h3>
    <p class="muted" style="margin:0">Looking for photos and videos</p>
  </section>`;
}

/* ------------------------------------------------------------
   Views — ready / category editor
   ------------------------------------------------------------ */
function viewReady() {
  const s = state.scan;
  if (!s) return viewSelect();
  const cats = state.categories;
  return `
  <section class="card">
    <div class="card-head">
      <h3><span class="step-num">2</span>Ready to sort</h3>
      <span class="sub">${s.skipped ? `${fmtInt(s.skipped)} unreadable item(s) skipped` : ""}</span>
    </div>
    <div class="sum-grid">
      <div><span class="sum-num">${fmtInt(s.total)}</span><span class="sum-label">Photos &amp; videos</span></div>
      <div><span class="sum-num">${fmtBytes(s.total_size)}</span><span class="sum-label">Total size</span></div>
      <div><span class="sum-num">${fmtInt(s.photos)}</span><span class="sum-label">Photos</span></div>
      <div><span class="sum-num">${fmtInt(s.videos)}</span><span class="sum-label">Videos</span></div>
    </div>
    <div class="folder-path">${icon("folder")} <span>${esc(s.root)}</span></div>

    <div class="cat-editor">
      <div class="cat-editor-head">
        <button class="link" data-action="toggle-cats">${state.catsOpen ? "− Hide category options" : "+ Customize categories"}</button>
        <span class="small muted">${cats.length} categories</span>
      </div>
      ${state.catsOpen ? `
      <div class="cat-chips">
        ${cats.map((c) => `<span class="cat-chip">${esc(c.name)} <button data-action="remove-cat" data-name="${esc(c.name)}" title="Remove category" ${cats.length <= 1 ? "disabled" : ""}>×</button></span>`).join("")}
      </div>
      <div class="add-cat">
        <input id="newCat" class="input" placeholder="Add a category — e.g. Sunsets, Weddings, Receipts…" maxlength="60"/>
        <button class="btn secondary sm" data-action="add-cat">Add</button>
        <button class="btn ghost sm" data-action="reset-cats">Reset</button>
      </div>
      <p class="hint">Snapsort understands plain English. Add anything you want it to look for — it will create a folder for it.</p>` : ""}
    </div>

    <div class="ready-actions">
      <button class="btn ghost" data-action="back-select">← Choose a different folder</button>
      <button class="btn primary lg" data-action="analyze">${icon("spark")} Start AI sorting</button>
    </div>
  </section>

  <section class="card">
    <div class="card-head"><h3>What happens next</h3></div>
    <div class="features" style="margin-top:0">
      <div class="feature"><div class="fi">1</div><h4>Analyze</h4><p>Every photo and video is scanned by the on-device AI model. A progress bar shows exactly where things stand.</p></div>
      <div class="feature"><div class="fi">2</div><h4>Review</h4><p>Browse the results, filter by category and fix anything with a single click before a single file moves.</p></div>
      <div class="feature"><div class="fi">3</div><h4>Sort</h4><p>Files are moved into clean folders. A manifest records every move so nothing is ever a mystery.</p></div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------
   Views — analyzing
   ------------------------------------------------------------ */
function viewAnalyzing() {
  const total = (state.job && state.job.total) || (state.scan && state.scan.total) || 0;
  return `
  <section class="card analyze-card">
    <div class="an-head">
      <div class="spinner"></div>
      <div style="min-width:0">
        <h3>Looking through your memories…</h3>
        <p id="currentFile">Preparing…</p>
      </div>
      <div class="an-pct" id="pct">0%</div>
    </div>
    <div class="bar"><i id="bar"></i></div>
    <div class="an-stats">
      <span><b id="doneCount">0</b> / <b>${fmtInt(total)}</b> files</span>
      <span id="rate"></span>
      <span id="eta"></span>
      <span id="modelNote" class="pill-note"></span>
    </div>
    <div class="chips mt14" id="anCounts"></div>
    <div class="recent">
      <div class="recent-head">Recently classified</div>
      <div class="recent-grid" id="recent"></div>
    </div>
    <div class="mt22"><button class="btn ghost sm" data-action="cancel-analyze">Cancel</button></div>
  </section>`;
}

function startAnalyzePoll() {
  clearInterval(pollTimer);
  pollAnalyze();
  pollTimer = setInterval(pollAnalyze, 500);
}

async function pollAnalyze() {
  if (!state.job) return;
  try {
    const j = await api.get(`/api/job/${state.job.id}?since=${state.results.length}`);
    if (j.results && j.results.length) {
      state.results.push(...j.results);
      updateAnalyzeLive();
    }
    updateAnalyzeProgress(j);
    if (["done", "cancelled", "error"].includes(j.status)) {
      clearInterval(pollTimer);
      if (j.status === "error") {
        state.view = "ready";
        toast(j.error || "Analysis failed", "error");
        render();
        return;
      }
      if (!state.results.length) {
        state.view = "ready";
        toast("No files could be analyzed", "error");
        render();
        return;
      }
      state.view = "review";
      render();
    }
  } catch (err) { /* transient */ }
}

function updateAnalyzeProgress(j) {
  const total = j.total || (state.scan && state.scan.total) || 1;
  const done = j.done || 0;
  const p = Math.min(1, done / total);
  const bar = document.getElementById("bar");
  const pctEl = document.getElementById("pct");
  const doneEl = document.getElementById("doneCount");
  const curEl = document.getElementById("currentFile");
  if (bar) bar.style.width = `${(p * 100).toFixed(1)}%`;
  if (pctEl) pctEl.textContent = `${Math.round(p * 100)}%`;
  if (doneEl) doneEl.textContent = fmtInt(done);
  if (curEl && j.current) curEl.textContent = j.current;
  const elapsed = j.elapsed || 1;
  const rate = done / Math.max(0.2, elapsed);
  const rateEl = document.getElementById("rate");
  const etaEl = document.getElementById("eta");
  if (rateEl && done > 0) rateEl.textContent = `${rate.toFixed(1)} files/sec`;
  if (etaEl && done > 0 && done < total) {
    const eta = (total - done) / rate;
    etaEl.textContent = `~${fmtDuration(eta)} left`;
  }
}

function updateAnalyzeLive() {
  const c = counts();
  const el = document.getElementById("anCounts");
  if (el) {
    el.innerHTML = Object.entries(c).sort((a, b) => b[1] - a[1])
      .map(([n, k]) => `<span class="chip">${esc(n)} <b>${fmtInt(k)}</b></span>`).join("");
  }
  const recent = document.getElementById("recent");
  if (recent) {
    const items = state.results.slice(-12).reverse();
    recent.innerHTML = items.map((r) => `
      <div class="recent-item">
        <img loading="lazy" src="/api/thumb/${state.scan.scan_id}/${r.id}" alt=""/>
        <span class="rl">${esc(r.cat)}</span>
      </div>`).join("");
  }
}

/* ------------------------------------------------------------
   Views — review
   ------------------------------------------------------------ */
function chipsHTML() {
  const c = counts();
  const cats = Object.entries(c).sort((a, b) => b[1] - a[1]);
  return `<button class="chip ${state.filter === "All" ? "active" : ""}" data-action="filter" data-cat="All">All <b>${fmtInt(state.results.length)}</b></button>` +
    cats.map(([name, n]) => `<button class="chip ${state.filter === name ? "active" : ""}" data-action="filter" data-cat="${esc(name)}">${esc(name)} <b>${fmtInt(n)}</b></button>`).join("");
}

function itemHTML(r) {
  const cat = state.overrides.get(r.id) || r.cat;
  const edited = state.overrides.has(r.id);
  return `<div class="item">
    <button class="thumb${r.error ? " err" : ""}" data-action="open-cat-menu" data-id="${r.id}" title="${esc(r.relpath)}">
      <img loading="lazy" decoding="async" src="/api/thumb/${state.scan.scan_id}/${r.id}" alt=""/>
      ${r.kind === "video" ? `<span class="vbadge">▶</span>` : ""}
      <span class="pill">${esc(cat)}</span>
      ${edited ? `<span class="edited">EDITED</span>` : ""}
    </button>
    <div class="fname" title="${esc(r.name)}">${esc(r.name)}</div>
  </div>`;
}

function gridHTML() {
  const list = filteredResults();
  if (!list.length) return `<div class="empty" style="grid-column:1/-1">No files match this filter.</div>`;
  return list.slice(0, state.gridLimit).map(itemHTML).join("");
}

function sentinelText() {
  const list = filteredResults();
  return state.gridLimit < list.length ? "Loading more…" : "";
}

function sortbarHTML() {
  const n = state.results.length;
  const changed = state.overrides.size;
  return `<div class="sortbar">
    <div class="sortbar-info">
      <div class="sortbar-count"><b>${fmtInt(n)}</b> files → <input id="destName" class="dest-input" value="${esc(state.destName)}" title="Folder name inside your photos folder" spellcheck="false"/><span class="muted">/</span></div>
      <div class="muted small">Click any thumbnail to change its category${changed ? ` · <b style="color:#c9b8ff">${changed} changed</b>` : ""}</div>
    </div>
    <div class="sortbar-actions">
      ${changed ? `<button class="btn ghost sm" data-action="reset-overrides">Reset changes</button>` : ""}
      <button class="btn primary" data-action="sort">Move ${fmtInt(n)} files</button>
    </div>
  </div>`;
}

function viewReview() {
  return `
  <section class="card review-head">
    <div class="review-title">
      <div>
        <h3>Review &amp; sort</h3>
        <p>${fmtInt(state.results.length)} files analyzed · ${Object.keys(counts()).length} categories</p>
      </div>
      <button class="btn ghost sm" data-action="back-select">← Different folder</button>
    </div>
    <div class="toolbar">
      <input id="search" class="input search" placeholder="Search files…" value="${esc(state.search)}"/>
      <div class="chips" id="filters">${chipsHTML()}</div>
    </div>
  </section>
  <section class="review-body">
    <div class="grid" id="grid">${gridHTML()}</div>
    <div id="sentinel" class="sentinel">${sentinelText()}</div>
  </section>
  ${sortbarHTML()}`;
}

function refreshChips() {
  const el = document.getElementById("filters");
  if (el) el.innerHTML = chipsHTML();
}

function renderGridOnly() {
  const grid = document.getElementById("grid");
  const sentinel = document.getElementById("sentinel");
  if (grid) grid.innerHTML = gridHTML();
  if (sentinel) sentinel.textContent = sentinelText();
  updateSortbar();
  observeSentinel();
}

function updateSortbar() {
  const bar = document.querySelector(".sortbar");
  if (!bar) return;
  bar.outerHTML = sortbarHTML();
  const dest = document.getElementById("destName");
  if (dest) dest.addEventListener("input", () => { state.destName = dest.value.trim() || "Sorted"; });
}

function observeSentinel() {
  if (observer) observer.disconnect();
  const s = document.getElementById("sentinel");
  if (!s) return;
  observer = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting && state.gridLimit < filteredResults().length) {
      state.gridLimit += 240;
      renderGridOnly();
    }
  }, { rootMargin: "700px" });
  observer.observe(s);
}

/* ------------------------------------------------------------
   Category popover
   ------------------------------------------------------------ */
function openCatMenu(cardEl, fileId) {
  closeMenu();
  const current = state.overrides.get(fileId) ||
    (state.results.find((r) => r.id === fileId) || {}).cat;
  menuEl = document.createElement("div");
  menuEl.className = "cat-menu";
  menuEl.innerHTML = `<div class="cat-menu-title">Move to category</div>` +
    state.categories.map((c) => `
      <button data-action="pick-cat" data-id="${fileId}" data-cat="${esc(c.name)}" class="${current === c.name ? "current" : ""}">
        <span>${esc(c.name)}</span><span>${current === c.name ? "✓" : ""}</span>
      </button>`).join("") +
    `<button data-action="pick-cat" data-id="${fileId}" data-cat="Others" class="${current === "Others" ? "current" : ""}">
      <span>Others</span><span>${current === "Others" ? "✓" : ""}</span>
    </button>`;
  document.body.appendChild(menuEl);

  const rect = cardEl.getBoundingClientRect();
  const mw = menuEl.offsetWidth;
  const mh = menuEl.offsetHeight;
  let left = Math.min(rect.left, window.innerWidth - mw - 12);
  let top = rect.bottom + 8;
  if (top + mh > window.innerHeight - 12) top = Math.max(12, rect.top - mh - 8);
  menuEl.style.left = `${Math.max(12, left)}px`;
  menuEl.style.top = `${top}px`;
}

function closeMenu() {
  if (menuEl) { menuEl.remove(); menuEl = null; }
}

/* ------------------------------------------------------------
   Modal
   ------------------------------------------------------------ */
function openModal(html) {
  $modalRoot.innerHTML = `<div class="modal-backdrop" data-action="modal-backdrop">${html}</div>`;
}
function closeModal() { $modalRoot.innerHTML = ""; }

function openSortConfirm() {
  const c = counts();
  const rows = Object.entries(c).sort((a, b) => b[1] - a[1])
    .map(([n, k]) => `<div class="mrow"><span>${esc(n)}</span><b>${fmtInt(k)}</b></div>`).join("");
  openModal(`<div class="modal">
    <h3>Move ${fmtInt(state.results.length)} files?</h3>
    <p>Files will be <b>moved</b> (not copied) into <code>${esc(state.destName)}/</code> inside <code>${esc(state.scan.root)}</code>. Originals will no longer be in their current folders.</p>
    <div class="mlist">${rows}</div>
    <p class="hint" style="margin-top:0">A manifest logging every move is saved inside the destination folder. Tip: keep a backup before your first big sort.</p>
    <div class="mactions">
      <button class="btn ghost" data-action="close-modal">Cancel</button>
      <button class="btn primary" data-action="confirm-sort">Move files</button>
    </div>
  </div>`);
}

/* ------------------------------------------------------------
   Views — sorting & done
   ------------------------------------------------------------ */
function viewSorting() {
  return `
  <section class="card analyze-card">
    <div class="an-head">
      <div class="spinner"></div>
      <div style="min-width:0">
        <h3>Moving your files…</h3>
        <p id="sortCurrent">Preparing…</p>
      </div>
      <div class="an-pct" id="sortPct">0%</div>
    </div>
    <div class="bar"><i id="sortBar"></i></div>
    <div class="an-stats" id="sortStats"></div>
    <div class="mt22"><button class="btn ghost sm" data-action="cancel-sort">Stop</button></div>
  </section>`;
}

function startSortPoll() {
  clearInterval(pollTimer);
  pollSort();
  pollTimer = setInterval(pollSort, 400);
}

async function pollSort() {
  if (!state.sortJob) return;
  try {
    const j = await api.get(`/api/job/${state.sortJob.id}`);
    const total = j.total || state.sortJob.total || 1;
    const p = Math.min(1, (j.done || 0) / total);
    const bar = document.getElementById("sortBar");
    const pctEl = document.getElementById("sortPct");
    const stats = document.getElementById("sortStats");
    const cur = document.getElementById("sortCurrent");
    if (bar) bar.style.width = `${(p * 100).toFixed(1)}%`;
    if (pctEl) pctEl.textContent = `${Math.round(p * 100)}%`;
    if (cur && j.current) cur.textContent = j.current;
    if (stats) stats.innerHTML = `<span><b>${fmtInt(j.done)}</b> / <b>${fmtInt(total)}</b> files</span>`;
    if (["done", "cancelled", "error"].includes(j.status)) {
      clearInterval(pollTimer);
      if (j.status === "error" && !j.summary) {
        toast(j.error || "Sorting failed", "error");
        state.view = "review";
        render();
        return;
      }
      state.sortSummary = j.summary || {};
      state.view = "done";
      render();
    }
  } catch (err) { /* transient */ }
}

function viewDone() {
  const s = state.sortSummary || {};
  const byCat = Object.entries(s.by_category || {}).sort((a, b) => b[1] - a[1]);
  const folders = byCat.length;
  return `
  <section class="card done-card">
    <div class="success">✓</div>
    <h3>${fmtInt(s.moved || 0)} files sorted into ${folders} folder${folders === 1 ? "" : "s"}</h3>
    <p>
      Everything is now in <code>${esc(s.dest || "")}</code>
      ${s.errors ? `<br/><span class="warn">${fmtInt(s.errors)} file${s.errors === 1 ? "" : "s"} couldn't be moved.</span>` : ""}
      ${s.missing ? `<br/><span class="warn">${fmtInt(s.missing)} file${s.missing === 1 ? "" : "s"} were no longer found.</span>` : ""}
    </p>
    <div class="result-cats">
      ${byCat.map(([name, n]) => `<div class="result-cat"><span class="rf">${icon("folder")}</span><span class="rn">${esc(name)}</span><span class="rc">${fmtInt(n)}</span></div>`).join("")}
    </div>
    <p class="hint">A full log of every move is saved in <code>_snapsort_manifest.json</code> inside the Sorted folder.</p>
    <div class="done-actions">
      <button class="btn primary" data-action="open-dest">Open Sorted folder</button>
      <button class="btn secondary" data-action="restart">Sort another folder</button>
    </div>
  </section>`;
}

/* ------------------------------------------------------------
   Actions
   ------------------------------------------------------------ */
async function doScan() {
  const input = document.getElementById("folderPath");
  const rec = document.getElementById("recursive");
  const path = (input ? input.value : "").trim();
  if (!path) { toast("Choose a folder first", "error"); return; }
  state.view = "scanning";
  render();
  try {
    const data = await api.post("/api/scan", { path, recursive: rec ? rec.checked : true });
    state.scan = data;
    state.view = "ready";
    state.catsOpen = false;
    state.filter = "All";
    state.search = "";
    state.results = [];
    state.overrides.clear();
    render();
    if (!data.total) toast("No photos or videos found in that folder", "error");
  } catch (err) {
    state.view = "select";
    render();
    toast(err.message, "error");
  }
}

async function addCategory() {
  const input = document.getElementById("newCat");
  const name = input ? input.value.trim() : "";
  if (!name) return;
  if (state.categories.some((c) => c.name.toLowerCase() === name.toLowerCase())) {
    toast("That category already exists", "error");
    return;
  }
  state.categories.push({ name });
  state.catsOpen = true;
  render();
  setTimeout(() => { const el = document.getElementById("newCat"); if (el) el.focus(); }, 40);
}

async function analyze() {
  try {
    const data = await api.post("/api/analyze", {
      scan_id: state.scan.scan_id,
      categories: state.categories.map((c) => ({ name: c.name })),
    });
    state.job = { id: data.job_id, total: data.total };
    state.results = [];
    state.overrides.clear();
    state.filter = "All";
    state.search = "";
    state.gridLimit = 240;
    state.view = "analyzing";
    render();
  } catch (err) {
    toast(err.message, "error");
  }
}

async function handleAction(action, el) {
  switch (action) {
    case "browse": {
      try {
        const res = await api.post("/api/pick-folder");
        if (res.ok && res.path) {
          const input = document.getElementById("folderPath");
          if (input) { input.value = res.path; input.focus(); }
        } else if (res.error && res.error !== "cancelled") {
          toast("Folder picker unavailable — paste the folder path instead", "error");
        }
      } catch (_) {
        toast("Folder picker unavailable — paste the folder path instead", "error");
      }
      break;
    }
    case "scan": doScan(); break;
    case "demo": {
      state.view = "scanning"; render();
      try {
        const data = await api.post("/api/demo");
        state.scan = data;
        state.view = "ready";
        state.catsOpen = false;
        render();
      } catch (err) {
        state.view = "select"; render(); toast(err.message, "error");
      }
      break;
    }
    case "back-select": state.view = "select"; render(); break;
    case "toggle-cats": state.catsOpen = !state.catsOpen; render(); break;
    case "add-cat": addCategory(); break;
    case "remove-cat": {
      const name = el.dataset.name;
      if (state.categories.length <= 1) { toast("Keep at least one category", "error"); break; }
      state.categories = state.categories.filter((c) => c.name !== name);
      render();
      break;
    }
    case "reset-cats":
      state.categories = state.config.categories.map((c) => ({ ...c }));
      render();
      break;
    case "analyze": analyze(); break;
    case "cancel-analyze": {
      try {
        await api.post(`/api/job/${state.job.id}/cancel`);
        toast("Stopping analysis…");
      } catch (err) { toast(err.message, "error"); }
      break;
    }
    case "filter": {
      state.filter = el.dataset.cat;
      state.gridLimit = 240;
      refreshChips();
      renderGridOnly();
      break;
    }
    case "open-cat-menu": {
      const id = el.dataset.id;
      openCatMenu(el, id);
      break;
    }
    case "pick-cat": {
      const id = el.dataset.id;
      const cat = el.dataset.cat;
      const r = state.results.find((x) => x.id === id);
      if (!r) break;
      if (cat === r.cat) state.overrides.delete(id);
      else state.overrides.set(id, cat);
      closeMenu();
      refreshChips();
      renderGridOnly();
      break;
    }
    case "reset-overrides":
      state.overrides.clear();
      render();
      break;
    case "sort":
      openSortConfirm();
      break;
    case "confirm-sort": {
      const dest = (document.getElementById("destName") || {}).value || state.destName;
      state.destName = dest.trim() || "Sorted";
      closeModal();
      try {
        const overrides = {};
        for (const [k, v] of state.overrides) overrides[k] = v;
        const data = await api.post("/api/sort", {
          scan_id: state.scan.scan_id,
          job_id: state.job.id,
          overrides,
          dest_name: state.destName,
        });
        state.sortJob = { id: data.job_id, total: data.total, dest: data.dest };
        state.view = "sorting";
        render();
      } catch (err) {
        toast(err.message, "error");
      }
      break;
    }
    case "cancel-sort": {
      try { await api.post(`/api/job/${state.sortJob.id}/cancel`); toast("Stopping…"); }
      catch (err) { toast(err.message, "error"); }
      break;
    }
    case "open-dest": {
      const dest = state.sortSummary && state.sortSummary.dest;
      if (!dest) break;
      try {
        await api.post("/api/open-folder", { path: dest });
      } catch (err) { toast(err.message, "error"); }
      break;
    }
    case "restart":
      state.scan = null;
      state.job = null;
      state.results = [];
      state.overrides.clear();
      state.sortJob = null;
      state.sortSummary = null;
      state.filter = "All";
      state.search = "";
      state.view = "select";
      render();
      break;
    case "close-modal":
      closeModal();
      break;
  }
}

/* ------------------------------------------------------------
   Global event wiring
   ------------------------------------------------------------ */
document.addEventListener("click", async (e) => {
  const el = e.target.closest("[data-action]");
  if (!el) { closeMenu(); return; }
  const action = el.dataset.action;
  if (action === "modal-backdrop") {
    if (e.target === el) closeModal();
    return;
  }
  try {
    await handleAction(action, el);
  } catch (err) {
    toast(err.message || "Something went wrong", "error");
  }
  if (!["open-cat-menu", "pick-cat"].includes(action)) closeMenu();
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") { closeMenu(); closeModal(); }
});
