#!/bin/bash
cd "$(dirname "$0")"
if [ -x ".venv/bin/python" ]; then
  .venv/bin/python run.py
else
  python3 run.py
fi
