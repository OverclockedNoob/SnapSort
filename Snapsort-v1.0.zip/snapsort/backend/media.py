"""Image/video loading, frame extraction and thumbnail generation."""
from __future__ import annotations

import hashlib
import os
import threading
import uuid
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

from . import config

try:  # HEIC/HEIF (iPhone photos)
    from pillow_heif import register_heif_opener

    register_heif_opener()
    HAS_HEIF = True
except Exception:  # pragma: no cover - optional dependency
    HAS_HEIF = False

try:  # RAW camera files (CR2, NEF, ARW, DNG, ...)
    import rawpy

    HAS_RAW = True
except Exception:  # pragma: no cover - optional dependency
    HAS_RAW = False

import cv2  # noqa: E402

# Quiet OpenCV/FFmpeg logging for broken files. The API differs between builds,
# so try both spellings and ignore failures entirely.
try:
    if hasattr(cv2, "setLogLevel"):
        cv2.setLogLevel(3)
    elif hasattr(cv2, "utils") and hasattr(cv2.utils, "logging"):
        cv2.utils.logging.setLogLevel(cv2.utils.logging.LOG_LEVEL_ERROR)
except Exception:
    pass

Image.MAX_IMAGE_PIXELS = 89_000_000  # guard against decompression bombs


# ---------------------------------------------------------------------------
# Decoding
# ---------------------------------------------------------------------------
def _load_raw(path: str) -> Image.Image | None:
    if not HAS_RAW:
        return None
    try:
        with rawpy.imread(path) as raw:
            rgb = raw.postprocess(half_size=True, output_bps=8, use_camera_wb=True)
        return Image.fromarray(rgb)
    except Exception:
        return None


def load_pil(path: str, max_dim: int | None = None) -> Image.Image | None:
    """Open any supported image (incl. HEIC / RAW) as an RGB PIL image.

    JPEGs are decoded at a reduced size (DCT scaling) when *max_dim* is given,
    which keeps memory low and is much faster for big camera photos.
    """
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in config.RAW_EXTS:
            img = _load_raw(path)
            if img is None:
                return None
            img = ImageOps.exif_transpose(img).convert("RGB")
        else:
            with Image.open(path) as im:
                if max_dim and im.format == "JPEG":
                    im.draft("RGB", (max_dim, max_dim))
                img = ImageOps.exif_transpose(im).convert("RGB")
        if max_dim and max(img.size) > max_dim:
            img.thumbnail((max_dim, max_dim), Image.LANCZOS)
        return img
    except (UnidentifiedImageError, OSError, ValueError):
        return None
    except Exception:
        return None


def video_frames(path: str, n: int = config.VIDEO_FRAMES, max_dim: int = 640) -> list[Image.Image]:
    """Sample up to *n* evenly spaced frames from a video, as RGB PIL images."""
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        return []
    frames: list[Image.Image] = []
    try:
        count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        fractions = [0.2, 0.5, 0.8, 0.35, 0.65][:n]
        if count > 0:
            for frac in fractions:
                cap.set(cv2.CAP_PROP_POS_FRAMES, max(0, min(count - 1, int(count * frac))))
                ok, frame = cap.read()
                if ok and frame is not None:
                    frames.append(_frame_to_pil(frame, max_dim))
        if not frames:  # fall back to reading the first frames sequentially
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            for _ in range(max(1, n)):
                ok, frame = cap.read()
                if not ok or frame is None:
                    break
                frames.append(_frame_to_pil(frame, max_dim))
    except Exception:
        return frames
    finally:
        cap.release()
    return frames


def _frame_to_pil(frame: np.ndarray, max_dim: int) -> Image.Image:
    img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    if max(img.size) > max_dim:
        img.thumbnail((max_dim, max_dim), Image.LANCZOS)
    return img


CLASSIFY_MAX_DIM = 448  # plenty for CLIP's 224px centre crop


def decode_entry(root: str, entry: dict) -> list[Image.Image]:
    """Decode a scanned file into small images for classification.

    Images are downscaled on decode so a batch never holds full-resolution
    camera photos in memory (important when sorting thousands of files).
    """
    path = os.path.join(root, entry["relpath"])
    if entry["kind"] == "video":
        frames = video_frames(path, max_dim=CLASSIFY_MAX_DIM)
        return [im for im in frames if max(im.size) > 1]
    img = load_pil(path, max_dim=CLASSIFY_MAX_DIM)
    return [img] if img is not None else []


# ---------------------------------------------------------------------------
# Thumbnails (disk-cached, used by the review grid)
# ---------------------------------------------------------------------------
def thumb_key(path: str, mtime: float, kind: str, size: int) -> str:
    raw = f"{os.path.abspath(path)}|{mtime}|{kind}|{size}".encode("utf-8", "replace")
    return hashlib.sha1(raw).hexdigest()


_thumb_locks: dict[str, threading.Lock] = {}
_thumb_locks_guard = threading.Lock()


def _thumb_lock(key: str) -> threading.Lock:
    with _thumb_locks_guard:
        lock = _thumb_locks.get(key)
        if lock is None:
            lock = threading.Lock()
            _thumb_locks[key] = lock
        return lock


def get_thumbnail(path: str, kind: str, mtime: float = 0.0,
                  size: int = config.THUMB_SIZE) -> Path | None:
    """Return a cached JPEG thumbnail path for a media file (or None).

    A per-key lock stops two parallel requests for the same file from
    generating the thumbnail twice (and racing on the temp file).
    """
    config.THUMB_DIR.mkdir(parents=True, exist_ok=True)
    key = thumb_key(path, mtime, kind, size)
    out = config.THUMB_DIR / f"{key}.jpg"
    if out.exists():
        return out

    with _thumb_lock(key):
        if out.exists():
            return out
        tmp = config.THUMB_DIR / f"{key}.{uuid.uuid4().hex}.tmp"
        try:
            if kind == "video":
                frames = video_frames(path, n=1, max_dim=max(512, size))
                if not frames:
                    return None
                img = frames[0]
            else:
                img = load_pil(path, max_dim=size)
                if img is None:
                    return None
            img = img.convert("RGB")
            img.thumbnail((size, size), Image.LANCZOS)
            img.save(tmp, "JPEG", quality=82, optimize=True)
            os.replace(tmp, out)
            return out
        except Exception:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass
            return None
