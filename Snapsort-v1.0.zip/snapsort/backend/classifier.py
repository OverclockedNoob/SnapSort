"""CLIP zero-shot classifier (ONNX, CPU) + model download/progress."""
from __future__ import annotations

import json
import os
import threading
import time
import urllib.request

import numpy as np
from PIL import Image

from . import config

_status_lock = threading.Lock()
_status = {"state": "idle", "progress": 0.0, "error": None, "detail": ""}


def get_model_status() -> dict:
    with _status_lock:
        return dict(_status)


def _set_status(state: str, progress: float = 0.0, error: str | None = None, detail: str = "") -> None:
    with _status_lock:
        _status.update({"state": state, "progress": progress, "error": error, "detail": detail})


def _download_file(filename: str, remote_path: str, progress_cb=None) -> None:
    url = f"{config.MODEL_BASE_URL}/{remote_path}"
    dest = config.MODEL_DIR / filename
    tmp = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": "snapsort/1.0"})
    with urllib.request.urlopen(req, timeout=120) as resp, open(tmp, "wb") as fh:
        total = int(resp.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = resp.read(1 << 20)
            if not chunk:
                break
            fh.write(chunk)
            done += len(chunk)
            if progress_cb:
                progress_cb(done, total, filename)
    if dest.exists():
        dest.unlink()
    os.replace(tmp, dest)


def ensure_model() -> None:
    """Download any missing model files, reporting progress."""
    missing = [k for k in config.MODEL_FILES if not (config.MODEL_DIR / k).exists()]
    if not missing:
        _set_status("ready", 1.0)
        return

    config.MODEL_DIR.mkdir(parents=True, exist_ok=True)
    _set_status("downloading", 0.0, detail="Connecting…")

    sizes = {}
    for name in missing:
        url = f"{config.MODEL_BASE_URL}/{config.MODEL_FILES[name]}"
        try:
            req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "snapsort/1.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                sizes[name] = int(r.headers.get("Content-Length") or 0)
        except Exception:
            sizes[name] = 0

    grand_total = sum(sizes.values()) or 1
    done_before = 0

    for name in missing:
        _set_status("downloading", done_before / grand_total,
                    detail=f"Downloading {name}…")

        def cb(done: int, total: int, fname: str = name, before: int = done_before) -> None:
            _set_status("downloading", min(0.999, (before + done) / grand_total),
                        detail=f"Downloading {fname}…")

        _download_file(name, config.MODEL_FILES[name], progress_cb=cb)
        done_before += sizes[name]

    _set_status("ready", 1.0)


class Classifier:
    """Thread-safe-ish singleton wrapping the ONNX CLIP session."""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
        return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        with self._lock:
            if self._initialized:
                return
            ensure_model()
            if get_model_status()["state"] == "error":
                raise RuntimeError("AI model is unavailable")

            import onnxruntime as ort  # local import: slow + optional
            from tokenizers import Tokenizer

            self._set_status("loading", 1.0, detail="Loading AI model…")
            self.tokenizer = Tokenizer.from_file(str(config.MODEL_DIR / "tokenizer.json"))
            self.session = ort.InferenceSession(
                str(config.MODEL_DIR / "model_quantized.onnx"),
                providers=["CPUExecutionProvider"],
            )
            with open(config.MODEL_DIR / "preprocessor_config.json", encoding="utf-8") as fh:
                pre = json.load(fh)
            self.mean = np.array(pre.get("image_mean", [0.48145466, 0.4578275, 0.40821073]), dtype=np.float32)
            self.std = np.array(pre.get("image_std", [0.26862954, 0.26130258, 0.27577711]), dtype=np.float32)
            crop = pre.get("crop_size", 224)
            if isinstance(crop, dict):
                crop = crop.get("height") or crop.get("width") or 224
            self.size = int(crop)

            # Dummy text input so the vision branch can run alone.
            enc = self.tokenizer.encode("a photo", add_special_tokens=True)
            self._dummy_ids = np.array([enc.ids], dtype=np.int64)
            self._dummy_am = np.array([enc.attention_mask], dtype=np.int64)

            self.category_names: list[str] = []
            self.text_embeddings: np.ndarray | None = None
            self._cat_lock = threading.Lock()
            self._out_index = {o.name: i for i, o in enumerate(self.session.get_outputs())}
            self._set_status("ready", 1.0, detail="Model ready")
            self._initialized = True

    @staticmethod
    def _set_status(state: str, progress: float = 1.0, detail: str = "") -> None:
        _set_status(state, progress, detail=detail)

    # -- prompt encoding -----------------------------------------------------
    def set_categories(self, categories: list[dict]) -> None:
        """Pre-compute normalized text embeddings for the category list."""
        with self._cat_lock:
            names, embs = [], []
            for cat in categories:
                prompts = cat.get("prompts") or config.prompts_for_category(cat["name"])
                encs = [self.tokenizer.encode(p, add_special_tokens=True) for p in prompts]
                maxlen = max(len(e.ids) for e in encs)
                ids = np.zeros((len(encs), maxlen), dtype=np.int64)
                am = np.zeros((len(encs), maxlen), dtype=np.int64)
                for i, e in enumerate(encs):
                    ids[i, : len(e.ids)] = e.ids
                    am[i, : len(e.attention_mask)] = e.attention_mask
                out = self.session.run(None, {
                    "input_ids": ids,
                    "attention_mask": am,
                    "pixel_values": np.zeros((1, 3, self.size, self.size), dtype=np.float32),
                })
                emb = np.asarray(out[self._out_index["text_embeds"]], dtype=np.float32)
                emb = emb / np.linalg.norm(emb, axis=1, keepdims=True).clip(min=1e-8)
                emb = emb.mean(axis=0)
                emb = emb / max(float(np.linalg.norm(emb)), 1e-8)
                embs.append(emb)
                names.append(cat["name"])
            self.category_names = names
            self.text_embeddings = np.stack(embs).astype(np.float32)

    # -- image branch --------------------------------------------------------
    def _preprocess(self, img: Image.Image) -> np.ndarray:
        img = img.convert("RGB")
        w, h = img.size
        scale = self.size / max(1, min(w, h))
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
        if (nw, nh) != (w, h):
            img = img.resize((nw, nh), Image.BICUBIC)
        left = (img.width - self.size) // 2
        top = (img.height - self.size) // 2
        img = img.crop((left, top, left + self.size, top + self.size))
        arr = np.asarray(img, dtype=np.float32) / 255.0
        arr = (arr - self.mean) / self.std
        return arr.transpose(2, 0, 1)

    def predict_probs(self, images: list[Image.Image]) -> np.ndarray:
        """Return a (batch, categories) probability matrix."""
        with self._cat_lock:
            text_embeddings = self.text_embeddings
            category_names = self.category_names
        if not images or text_embeddings is None:
            return np.zeros((0, len(category_names)), dtype=np.float32)
        arr = np.stack([self._preprocess(im) for im in images]).astype(np.float32)
        out = self.session.run(None, {
            "pixel_values": arr,
            "input_ids": self._dummy_ids,
            "attention_mask": self._dummy_am,
        })
        emb = np.asarray(out[self._out_index["image_embeds"]], dtype=np.float32)  # (B, 512)
        emb = emb / np.linalg.norm(emb, axis=1, keepdims=True).clip(min=1e-8)
        logits = 100.0 * (emb @ text_embeddings.T)
        z = logits - logits.max(axis=1, keepdims=True)
        probs = np.exp(z)
        probs /= probs.sum(axis=1, keepdims=True).clip(min=1e-8)
        return probs.astype(np.float32)

    def probs_to_result(self, probs: np.ndarray) -> dict:
        order = np.argsort(-probs)
        top = int(order[0])
        label = self.category_names[top]
        conf = float(probs[top])
        if conf < config.CONFIDENCE_THRESHOLD:
            label = config.OTHERS_CATEGORY
        return {
            "label": label,
            "conf": round(conf, 4),
            "top": [
                [self.category_names[int(i)], round(float(probs[int(i)]), 3)]
                for i in order[:3]
            ],
        }


def preload() -> None:
    """Background warm-up: download model + build the ONNX session."""
    try:
        Classifier()
        _set_status("ready", 1.0, detail="Model ready")
    except Exception as exc:  # pragma: no cover
        _set_status("error", 0.0, error=str(exc), detail=str(exc))


def preload_and_wait(timeout: float = 1800) -> dict:
    """Block until the model is ready (used by long-running jobs)."""
    start = time.time()
    try:
        Classifier()
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "waited": round(time.time() - start, 1)}
