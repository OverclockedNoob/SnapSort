"""In-memory background job manager with progress + incremental results."""
from __future__ import annotations

import threading
import time
import uuid


class Job:
    def __init__(self, kind: str, total: int = 0):
        self.id = uuid.uuid4().hex[:12]
        self.kind = kind
        self.status = "running"
        self.total = total
        self.done = 0
        self.current = ""
        self.results: list[dict] = []
        self.counts: dict[str, int] = {}
        self.error: str | None = None
        self.cancelled = False
        self.summary: dict = {}
        self.started_at = time.time()
        self.finished_at: float | None = None
        self._lock = threading.Lock()

    def add_result(self, item: dict) -> None:
        with self._lock:
            self.results.append(item)
            self.done += 1
            self.current = item.get("name", "")
            cat = item.get("cat", "Others")
            self.counts[cat] = self.counts.get(cat, 0) + 1

    def add_done(self, name: str = "") -> None:
        with self._lock:
            self.done += 1
            self.current = name

    def finish(self, status: str | None = None, summary: dict | None = None) -> None:
        with self._lock:
            if status:
                self.status = status
            elif self.status == "running":
                self.status = "done"
            if summary is not None:
                self.summary = summary
            self.finished_at = time.time()

    def to_dict(self, since: int = 0) -> dict:
        with self._lock:
            return {
                "id": self.id,
                "kind": self.kind,
                "status": self.status,
                "total": self.total,
                "done": self.done,
                "current": self.current,
                "results": self.results[since:],
                "counts": dict(self.counts),
                "error": self.error,
                "summary": dict(self.summary),
                "elapsed": round((self.finished_at or time.time()) - self.started_at, 1),
            }


class JobManager:
    def __init__(self, keep: int = 10):
        self.jobs: dict[str, Job] = {}
        self._lock = threading.Lock()
        self.keep = keep

    def create(self, kind: str, total: int = 0) -> Job:
        job = Job(kind, total)
        with self._lock:
            self.jobs[job.id] = job
            while len(self.jobs) > self.keep:
                self.jobs.pop(next(iter(self.jobs)))
        return job

    def get(self, job_id: str) -> Job | None:
        return self.jobs.get(job_id)

    def cancel(self, job_id: str) -> bool:
        job = self.jobs.get(job_id)
        if job:
            job.cancelled = True
            return True
        return False
