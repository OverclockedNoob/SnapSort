"""FastAPI application — REST API + static UI."""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
from fastapi import Body, FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import classifier, config, media, scanner, sorter
from .jobs import JobManager

app = FastAPI(title=config.APP_NAME, version=config.APP_VERSION)

JOBS = JobManager(keep=12)
SCANS: Dict[str, dict] = {}
_SCANS_LOCK = threading.Lock()
_KEEP_SCANS = 4

app.mount("/static", StaticFiles(directory=str(config.STATIC_DIR)), name="static")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _register_scan(result: dict) -> dict:
    scan_id = uuid.uuid4().hex[:12]
    entry = dict(result)
    entry["id"] = scan_id
    entry["index"] = {f["id"]: f for f in result["files"]}
    entry["created"] = time.time()
    with _SCANS_LOCK:
        SCANS[scan_id] = entry
        while len(SCANS) > _KEEP_SCANS:
            SCANS.pop(next(iter(SCANS)))
    return entry


def _get_scan(scan_id: str) -> dict:
    scan = SCANS.get(scan_id)
    if not scan:
        raise HTTPException(404, "Scan not found — please scan the folder again")
    return scan


def _scan_payload(scan: dict) -> dict:
    files = scan["files"]
    total_size = sum(f["size"] for f in files)
    return {
        "scan_id": scan["id"],
        "root": scan["root"],
        "total": len(files),
        "total_size": total_size,
        "photos": sum(1 for f in files if f["kind"] == "image"),
        "videos": sum(1 for f in files if f["kind"] == "video"),
        "skipped": scan.get("skipped", 0),
        "truncated": scan.get("truncated", False),
        "files": files,
    }


def _inside(path: str, root: str) -> bool:
    p = os.path.abspath(path)
    r = os.path.abspath(root)
    return p == r or p.startswith(r + os.sep)


def _allowed_path(path: str) -> bool:
    with _SCANS_LOCK:
        roots = [s["root"] for s in SCANS.values()]
    return any(_inside(path, r) for r in roots)


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
class CategoryIn(BaseModel):
    name: str = Field(..., min_length=1, max_length=60)
    prompts: Optional[List[str]] = None


class ScanRequest(BaseModel):
    path: str = Field(..., min_length=1)
    recursive: bool = True


class AnalyzeRequest(BaseModel):
    scan_id: str
    categories: Optional[List[CategoryIn]] = None


class SortRequest(BaseModel):
    scan_id: str
    job_id: str
    overrides: Dict[str, str] = {}
    dest_name: str = config.DEST_DIR_NAME
    mode: str = "move"


class OpenFolderRequest(BaseModel):
    path: str


# ---------------------------------------------------------------------------
# Analyze job
# ---------------------------------------------------------------------------
def _run_analyze(job, scan: dict, categories: list[dict]) -> None:
    try:
        clf = classifier.Classifier()
        clf.set_categories(categories)
        files = scan["files"]
        job.total = len(files)
        if not files:
            job.finish("done", {"message": "Nothing to analyze"})
            return

        executor = ThreadPoolExecutor(max_workers=config.DECODE_WORKERS)
        try:
            for start in range(0, len(files), config.BATCH_SIZE):
                if job.cancelled:
                    job.finish("cancelled")
                    return
                chunk = files[start:start + config.BATCH_SIZE]
                decoded = list(executor.map(lambda f: media.decode_entry(scan["root"], f), chunk))

                flat: list = []
                counts: list[int] = []
                for imgs in decoded:
                    flat.extend(imgs)
                    counts.append(len(imgs))

                if flat:
                    probs = clf.predict_probs(flat)
                else:
                    probs = np.zeros((0, len(categories)), dtype=np.float32)

                idx = 0
                for f, n in zip(chunk, counts):
                    if n == 0:
                        res = {"label": config.OTHERS_CATEGORY, "conf": 0.0,
                               "top": [], "error": "unreadable"}
                    else:
                        row = probs[idx:idx + n].mean(axis=0)
                        res = clf.probs_to_result(row)
                    idx += n
                    job.add_result({
                        "id": f["id"],
                        "name": f["name"],
                        "relpath": f["relpath"],
                        "kind": f["kind"],
                        "cat": res["label"],
                        "conf": res["conf"],
                        "top": res["top"],
                        **({"error": res["error"]} if "error" in res else {}),
                    })
        finally:
            executor.shutdown(wait=False)
        job.finish("cancelled" if job.cancelled else "done")
    except Exception as exc:
        job.finish("error", {"message": str(exc)})


def _run_sort(job, scan: dict, assignments: dict[str, str], dest_root: str) -> None:
    try:
        sorter.sort_files(job, scan, assignments, dest_root)
    except Exception as exc:
        job.finish("error", {"message": str(exc)})


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------
@app.get("/api/config")
def get_config():
    cats = [{"name": c["name"]} for c in config.DEFAULT_CATEGORIES]
    demo = bool(config.DEMO_DIR and os.path.isdir(config.DEMO_DIR))
    return {
        "app": config.APP_NAME,
        "version": config.APP_VERSION,
        "categories": cats,
        "dest_name": config.DEST_DIR_NAME,
        "demo_available": demo,
        "demo_dir": config.DEMO_DIR if demo else "",
        "model": classifier.get_model_status(),
        "supported": sorted(config.IMAGE_EXTS | config.RAW_EXTS | config.VIDEO_EXTS),
    }


@app.get("/api/model-status")
def model_status():
    return classifier.get_model_status()


@app.post("/api/pick-folder")
def pick_folder():
    """Open the OS folder picker (runs tkinter in a subprocess for stability)."""
    code = (
        "import tkinter as tk\n"
        "from tkinter import filedialog\n"
        "r=tk.Tk(); r.withdraw(); r.attributes('-topmost', True)\n"
        "p=filedialog.askdirectory(title='Choose a folder to sort')\n"
        "print(p or '')\n"
    )
    try:
        res = subprocess.run([sys.executable, "-c", code], capture_output=True,
                             text=True, timeout=900)
        lines = [ln.strip() for ln in (res.stdout or "").splitlines() if ln.strip()]
        if lines:
            return {"ok": True, "path": lines[-1]}
        return {"ok": False, "error": "cancelled"}
    except Exception as exc:
        return {"ok": False, "error": f"dialog_unavailable: {exc}"}


@app.post("/api/scan")
def scan(req: ScanRequest):
    path = os.path.expanduser(req.path.strip().strip('"').strip("'"))
    if not path:
        raise HTTPException(400, "Please choose a folder")
    try:
        result = scanner.scan_folder(path, recursive=req.recursive)
    except FileNotFoundError:
        raise HTTPException(400, f"That folder doesn't exist: {path}")
    except NotADirectoryError:
        raise HTTPException(400, f"That's not a folder: {path}")
    except PermissionError:
        raise HTTPException(403, f"Permission denied: {path}")
    scan_entry = _register_scan(result)
    return {"ok": True, **_scan_payload(scan_entry)}


@app.post("/api/demo")
def demo_scan():
    if not config.DEMO_DIR or not os.path.isdir(config.DEMO_DIR):
        raise HTTPException(404, "Demo folder not available")
    result = scanner.scan_folder(config.DEMO_DIR, recursive=True)
    scan_entry = _register_scan(result)
    return {"ok": True, **_scan_payload(scan_entry)}


@app.post("/api/analyze")
def analyze(req: AnalyzeRequest):
    scan = _get_scan(req.scan_id)
    cats = config.with_defaults([c.model_dump() for c in req.categories] if req.categories else None)
    if len(scan["files"]) == 0:
        raise HTTPException(400, "No photos or videos found in that folder")
    job = JOBS.create("analyze", total=len(scan["files"]))
    threading.Thread(target=_run_analyze, args=(job, scan, cats), daemon=True).start()
    return {"job_id": job.id, "total": len(scan["files"]), "categories": [c["name"] for c in cats]}


@app.get("/api/job/{job_id}")
def get_job(job_id: str, since: int = 0):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    return job.to_dict(since=max(0, since))


@app.post("/api/job/{job_id}/cancel")
def cancel_job(job_id: str):
    ok = JOBS.cancel(job_id)
    if not ok:
        raise HTTPException(404, "Job not found")
    return {"ok": True}


@app.post("/api/sort")
def sort(req: SortRequest):
    scan = _get_scan(req.scan_id)
    job = JOBS.get(req.job_id)
    if not job or job.kind != "analyze":
        raise HTTPException(400, "Analyze the folder before sorting")
    if job.status not in ("done", "cancelled"):
        raise HTTPException(400, "Analysis is still running")

    results = {r["id"]: r["cat"] for r in job.results}
    assignments = {**results, **{k: v for k, v in req.overrides.items() if v}}
    if not assignments:
        raise HTTPException(400, "No analyzed files to sort")

    dest_input = (req.dest_name or config.DEST_DIR_NAME).strip()
    if os.path.isabs(dest_input):
        dest_root = os.path.abspath(os.path.expanduser(dest_input))
    else:
        dest_root = os.path.join(scan["root"], sorter.safe_folder_name(dest_input))

    if os.path.abspath(dest_root) == os.path.abspath(scan["root"]):
        raise HTTPException(400, "Destination can't be the same as the source folder")
    if os.path.abspath(scan["root"]).startswith(os.path.abspath(dest_root) + os.sep):
        raise HTTPException(400, "Destination can't be a parent of the source folder")

    move_job = JOBS.create("sort", total=len(assignments))
    threading.Thread(
        target=_run_sort, args=(move_job, scan, assignments, dest_root), daemon=True
    ).start()
    return {"job_id": move_job.id, "total": len(assignments), "dest": dest_root}


@app.get("/api/thumb/{scan_id}/{file_id}")
def thumb(scan_id: str, file_id: str):
    scan = _get_scan(scan_id)
    entry = scan["index"].get(file_id)
    if not entry:
        raise HTTPException(404, "File not found")
    path = os.path.join(scan["root"], entry["relpath"])
    if not os.path.exists(path):
        raise HTTPException(404, "File no longer exists")
    thumb_path = media.get_thumbnail(path, entry["kind"], entry.get("mtime", 0.0))
    if not thumb_path:
        return _placeholder(entry["kind"])
    return FileResponse(
        str(thumb_path), media_type="image/jpeg",
        headers={"Cache-Control": "public, max-age=86400"},
    )


def _placeholder(kind: str) -> Response:
    color = "#7c5cff" if kind == "video" else "#3b425f"
    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 240">
<rect width="320" height="240" fill="#161a2b"/>
<rect x="120" y="96" width="80" height="60" rx="10" fill="{color}" opacity="0.35"/>
<circle cx="160" cy="126" r="16" fill="{color}" opacity="0.8"/>
<rect x="140" y="86" width="24" height="10" rx="4" fill="{color}" opacity="0.6"/>
</svg>"""
    return Response(svg, media_type="image/svg+xml",
                    headers={"Cache-Control": "public, max-age=3600"})


@app.post("/api/open-folder")
def open_folder(req: OpenFolderRequest):
    path = os.path.abspath(os.path.expanduser(req.path))
    if not _allowed_path(path):
        raise HTTPException(403, "That folder is outside the scanned library")
    if not os.path.exists(path):
        raise HTTPException(404, "Folder not found")
    try:
        if sys.platform.startswith("win"):
            subprocess.Popen(["explorer", "/select,", path])
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R", path])
        else:
            target = path if os.path.isdir(path) else os.path.dirname(path)
            subprocess.Popen(["xdg-open", target])
        return {"ok": True}
    except Exception as exc:
        raise HTTPException(500, f"Could not open folder: {exc}")


@app.get("/api/health")
def health():
    return {"ok": True, "version": config.APP_VERSION}


@app.get("/")
def index():
    return FileResponse(str(config.STATIC_DIR / "index.html"))


@app.on_event("startup")
def _startup() -> None:
    threading.Thread(target=classifier.preload, daemon=True).start()
