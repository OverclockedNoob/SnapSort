"""Snapsort backend — local AI photo & video organizer."""

__version__ = "1.0.0"
