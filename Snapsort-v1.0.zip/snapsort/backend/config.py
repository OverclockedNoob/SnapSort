"""Central configuration for Snapsort."""
from __future__ import annotations

import os
from pathlib import Path

APP_NAME = "Snapsort"
APP_VERSION = "1.0.0"

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"


def _cache_dir() -> Path:
    custom = os.environ.get("SNAPSORT_CACHE_DIR")
    if custom:
        return Path(custom).expanduser()
    return Path.home() / ".cache" / "snapsort"


CACHE_DIR = _cache_dir()
MODEL_DIR = CACHE_DIR / "clip-vit-base-patch32"
THUMB_DIR = CACHE_DIR / "thumbs"

# ---------------------------------------------------------------------------
# AI model (CLIP, ONNX — quantized int8, ~154 MB, runs on CPU)
# ---------------------------------------------------------------------------
MODEL_REPO = "Xenova/clip-vit-base-patch32"
MODEL_BASE_URL = f"https://huggingface.co/{MODEL_REPO}/resolve/main"
MODEL_FILES = {
    "model_quantized.onnx": "onnx/model_quantized.onnx",
    "tokenizer.json": "tokenizer.json",
    "vocab.json": "vocab.json",
    "merges.txt": "merges.txt",
    "special_tokens_map.json": "special_tokens_map.json",
    "tokenizer_config.json": "tokenizer_config.json",
    "preprocessor_config.json": "preprocessor_config.json",
    "config.json": "config.json",
}

# ---------------------------------------------------------------------------
# File types
# ---------------------------------------------------------------------------
IMAGE_EXTS = {
    ".jpg", ".jpeg", ".png", ".heic", ".heif", ".webp",
    ".gif", ".bmp", ".tif", ".tiff", ".avif", ".jxl",
}
RAW_EXTS = {".dng", ".cr2", ".cr3", ".nef", ".arw", ".orf", ".rw2", ".pef", ".raf"}
VIDEO_EXTS = {
    ".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v",
    ".3gp", ".mts", ".m2ts", ".wmv", ".flv",
}
ALL_EXTS = IMAGE_EXTS | RAW_EXTS | VIDEO_EXTS


def is_media_ext(ext: str) -> bool:
    return ext.lower() in ALL_EXTS


def kind_of(ext: str) -> str:
    return "video" if ext.lower() in VIDEO_EXTS else "image"


# ---------------------------------------------------------------------------
# Sorting behaviour
# ---------------------------------------------------------------------------
DEST_DIR_NAME = "Sorted"
OTHERS_CATEGORY = "Others"
CONFIDENCE_THRESHOLD = 0.30  # below this, files land in "Others"
BATCH_SIZE = 16              # images per model call
DECODE_WORKERS = 3           # parallel file decoders
VIDEO_FRAMES = 3             # frames sampled per video for classification
THUMB_SIZE = 360             # thumbnail max dimension (px)
MAX_SCAN_FILES = 200_000

DEFAULT_CATEGORIES = [
    {
        "name": "People",
        "prompts": [
            "a photo of people",
            "a portrait of a person",
            "a group photo of friends and family",
            "a selfie taken with a phone",
            "people smiling at the camera",
        ],
    },
    {
        "name": "Food & Drinks",
        "prompts": [
            "a photo of food",
            "a plate of delicious food",
            "a drink in a glass",
            "a meal at a restaurant or cafe",
            "a cup of coffee or tea",
        ],
    },
    {
        "name": "Travel & Nature",
        "prompts": [
            "a beautiful landscape photo",
            "a travel photo of a famous landmark",
            "a beach or ocean scene",
            "mountains and nature scenery",
            "a city skyline at sunset",
        ],
    },
    {
        "name": "Events & Parties",
        "prompts": [
            "a birthday party with balloons and cake",
            "a wedding celebration",
            "a festival or concert crowd",
            "people celebrating with confetti",
        ],
    },
    {
        "name": "Screenshots",
        "prompts": [
            "a screenshot of a phone screen",
            "a screenshot of a chat conversation",
            "a screenshot of an app or website",
            "a screenshot of a social media post",
        ],
    },
    {
        "name": "Documents",
        "prompts": [
            "a photo of a document or paper",
            "a receipt or invoice",
            "a handwritten note or letter",
            "a page of printed text",
            "an ID card or passport",
        ],
    },
    {
        "name": "Pets & Animals",
        "prompts": [
            "a photo of a pet",
            "a cute cat",
            "a dog playing",
            "a wild animal or bird",
        ],
    },
    {
        "name": "Vehicles",
        "prompts": [
            "a photo of a car",
            "a motorcycle",
            "a train or an airplane",
            "a boat on water",
        ],
    },
    {
        "name": "Memes & Graphics",
        "prompts": [
            "an internet meme image",
            "a funny meme with caption text",
            "a viral meme with text on it",
            "a graphic design poster",
            "a cartoon or digital illustration",
        ],
    },
]


def prompts_for_category(name: str) -> list[str]:
    """Prompt templates for a user-defined category."""
    n = name.strip().lower()
    return [
        f"a photo of {n}",
        f"a picture of {n}",
        f"a close-up photo of {n}",
        n,
    ]


DEFAULT_BY_NAME = {c["name"]: c for c in DEFAULT_CATEGORIES}


def with_defaults(categories: list[dict] | None) -> list[dict]:
    """Return a normalized category list, falling back to the defaults."""
    if not categories:
        return [dict(c) for c in DEFAULT_CATEGORIES]
    out = []
    seen = set()
    for cat in categories:
        name = str(cat.get("name", "")).strip()
        if not name or name.lower() in seen:
            continue
        seen.add(name.lower())
        prompts = cat.get("prompts")
        if not prompts:
            prompts = DEFAULT_BY_NAME.get(name, {}).get("prompts") or prompts_for_category(name)
        out.append({"name": name, "prompts": prompts})
    return out or [dict(c) for c in DEFAULT_CATEGORIES]


DEMO_DIR = os.environ.get("SNAPSORT_DEMO_DIR") or str(BASE_DIR / "sample_photos")
