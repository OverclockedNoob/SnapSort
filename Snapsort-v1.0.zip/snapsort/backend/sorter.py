"""Moving files into category folders (with collision handling + manifest)."""
from __future__ import annotations

import json
import os
import re
import shutil
import time

from . import config

_INVALID = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def safe_folder_name(name: str) -> str:
    name = _INVALID.sub("", str(name)).strip().strip(".")
    name = re.sub(r"\s+", " ", name)
    if not name:
        name = config.OTHERS_CATEGORY
    return name[:80]


def unique_path(dirpath: str, filename: str) -> str:
    base, ext = os.path.splitext(filename)
    candidate = os.path.join(dirpath, filename)
    i = 2
    while os.path.exists(candidate):
        candidate = os.path.join(dirpath, f"{base} ({i}){ext}")
        i += 1
    return candidate


def sort_files(job, scan: dict, assignments: dict[str, str], dest_root: str) -> None:
    os.makedirs(dest_root, exist_ok=True)
    manifest: list[dict] = []
    moved = errors = missing = 0
    by_cat: dict[str, int] = {}

    try:
        for entry in scan["files"]:
            if job.cancelled:
                break
            cat = assignments.get(entry["id"]) or config.OTHERS_CATEGORY
            src = os.path.join(scan["root"], entry["relpath"])
            rec = {"from": entry["relpath"], "category": cat, "name": entry["name"]}

            if not os.path.exists(src):
                missing += 1
                rec["status"] = "missing"
                manifest.append(rec)
                job.add_done(entry["name"])
                continue

            try:
                cat_dir = os.path.join(dest_root, safe_folder_name(cat))
                os.makedirs(cat_dir, exist_ok=True)
                dst = unique_path(cat_dir, entry["name"])
                shutil.move(src, dst)
                moved += 1
                by_cat[cat] = by_cat.get(cat, 0) + 1
                rec["status"] = "moved"
                rec["to"] = os.path.relpath(dst, dest_root).replace(os.sep, "/")
            except Exception as exc:
                errors += 1
                rec["status"] = "error"
                rec["error"] = str(exc)

            manifest.append(rec)
            job.add_done(entry["name"])
    except Exception as exc:  # unexpected failure
        job.error = str(exc)
    finally:
        summary = {
            "moved": moved,
            "errors": errors,
            "missing": missing,
            "by_category": by_cat,
            "dest": dest_root,
            "total": len(scan["files"]),
        }
        manifest_path = os.path.join(dest_root, "_snapsort_manifest.json")
        try:
            with open(manifest_path, "w", encoding="utf-8") as fh:
                json.dump({
                    "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "source": scan["root"],
                    "destination": dest_root,
                    "items": manifest,
                }, fh, indent=1, ensure_ascii=False)
            summary["manifest"] = manifest_path
        except Exception:
            pass
        job.summary = summary
        job.finish("cancelled" if job.cancelled else ("error" if job.error else "done"), summary)
