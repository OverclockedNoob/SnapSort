"""Folder scanning."""
from __future__ import annotations

import hashlib
import os

from . import config


def file_id(relpath: str) -> str:
    return hashlib.sha1(relpath.encode("utf-8", "replace")).hexdigest()[:16]


def scan_folder(root: str, recursive: bool = True) -> dict:
    root = os.path.abspath(os.path.expanduser(root))
    if not os.path.exists(root):
        raise FileNotFoundError(root)
    if not os.path.isdir(root):
        raise NotADirectoryError(root)

    files: list[dict] = []
    skipped = 0

    def on_error(_exc: OSError) -> None:
        nonlocal skipped
        skipped += 1

    if recursive:
        walker = os.walk(root, topdown=True, onerror=on_error, followlinks=False)
        for dirpath, dirnames, filenames in walker:
            dirnames[:] = [
                d for d in sorted(dirnames)
                if not d.startswith(".") and d != config.DEST_DIR_NAME
            ]
            for fn in filenames:
                entry = _entry_for(root, dirpath, fn)
                if entry is None:
                    skipped += 1
                else:
                    files.append(entry)
                if len(files) >= config.MAX_SCAN_FILES:
                    return {"root": root, "files": files, "skipped": skipped, "truncated": True}
    else:
        try:
            names = sorted(os.listdir(root))
        except OSError:
            names = []
        for fn in names:
            full = os.path.join(root, fn)
            if not os.path.isfile(full):
                continue
            entry = _entry_for(root, root, fn)
            if entry is None:
                skipped += 1
            else:
                files.append(entry)

    files.sort(key=lambda f: f["relpath"].lower())
    return {"root": root, "files": files, "skipped": skipped, "truncated": False}


def _entry_for(root: str, dirpath: str, fn: str) -> dict | None:
    if fn.startswith("."):
        return None
    ext = os.path.splitext(fn)[1].lower()
    if not config.is_media_ext(ext):
        return None
    full = os.path.join(dirpath, fn)
    try:
        st = os.stat(full)
    except OSError:
        return None
    if not os.path.isfile(full):
        return None
    rel = os.path.relpath(full, root).replace(os.sep, "/")
    return {
        "id": file_id(rel),
        "relpath": rel,
        "name": fn,
        "size": st.st_size,
        "mtime": st.st_mtime,
        "kind": config.kind_of(ext),
        "ext": ext.lstrip("."),
    }
